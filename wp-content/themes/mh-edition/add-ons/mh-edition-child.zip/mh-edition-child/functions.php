<?php

/***** Load Stylesheets *****/

function mh_edition_child_styles() {
    wp_enqueue_style('mh-edition', get_template_directory_uri() . '/style.css');
    wp_enqueue_style('mh-edition-child', get_stylesheet_directory_uri() . '/style.css', array('mh-edition'));
}
add_action('wp_enqueue_scripts', 'mh_edition_child_styles');

?>