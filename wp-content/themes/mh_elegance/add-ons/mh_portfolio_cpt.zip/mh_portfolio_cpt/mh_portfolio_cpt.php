<?php
/*
Plugin Name: MH Portfolio CPT
Plugin URI: http://www.mhthemes.com/
Description: This plugin introduces a portfolio custom post type to your WordPress installation.
Version: 1.0.0
Author: MH Themes
Author URI: http://www.mhthemes.com/
Text Domain: mh-portfolio
Domain Path: /languages/
License: GNU General Public License v2 or later
*/

/***** Setup Plugin *****/

function mh_portfolio_setup() {
	load_plugin_textdomain('mh-portfolio', false, dirname(plugin_basename(__FILE__)) . '/languages/');
	add_image_size('portfolio', 307, 195, true);
}
add_action('init', 'mh_portfolio_setup');

/***** Register Custom Post Types & Taxonomies *****/

function mh_portfolio_register() {
	register_post_type('mh-portfolio', array(
		'labels' => array(
			'name' 			=> __('Projects', 'mh-portfolio'),
			'singular_name' => __('Project', 'mh-portfolio'),
			'menu_name' 	=> __('Portfolio', 'mh-portfolio'),
			'all_items'   	=> __('All Projects', 'mh-portfolio')
		),
		'supports' => array(
			'title',
			'thumbnail',
			'editor'
		),
		'rewrite' => array(
			'slug'       	=> 'portfolio',
			'with_front' 	=> false,
			'feeds'     	=> true,
			'pages'      	=> true,
		),
		'public' 			=> true,
		'has_archive' 		=> true,
		'menu_position' 	=> 20,
		'menu_icon' 		=> 'dashicons-portfolio',
		'capability_type' 	=> 'page',
		'query_var'       	=> 'portfolio',
	));
	register_taxonomy('mh-portfolio-type', 'mh-portfolio', array(
		'hierarchical' 	=> true,
		'label' 		=> __('Project Types', 'mh-portfolio'),
		'rewrite'       => array('slug' => 'project-type'),
	));
  	register_taxonomy('mh-portfolio-tag', 'mh-portfolio', array(
  		'hierarchical' 	=> true,
  		'label' 		=> __('Project Tags', 'mh-portfolio'),
  		'rewrite'       => array('slug' => 'project-tag'),
  	));
}
add_action('init', 'mh_portfolio_register');
register_activation_hook(__FILE__, 'mh_portfolio_register');
register_activation_hook(__FILE__, 'flush_rewrite_rules');
register_deactivation_hook(__FILE__, 'flush_rewrite_rules');

/***** Portfolio Shortcode *****/

function mh_portfolio_shortcode($atts) {
	$atts = shortcode_atts( array(
			'showposts' => '-1',
			'offset'	=>	''
	), $atts, 'mh_portfolio');
	$args = array('post_type' => 'mh-portfolio', 'posts_per_page' => esc_attr($atts['showposts']), 'offset' => intval($atts['offset']));
	$html = false;
	$portfolio = new WP_Query($args);
	$counter = 1;
	if ($portfolio->have_posts()) :
		$html = '<div class="portfolio-shortcode">' . "\n";
			$html .= '<div class="row clearfix">' . "\n";
			while ($portfolio->have_posts()) : $portfolio->the_post();
				$html .= '<article id="post-' . get_the_ID() . '" class="portfolio-item mh-col-1-3">' . "\n";
					$html .= '<div class="portfolio-thumb">' . "\n";
						$html .= '<a href="' . get_the_permalink() . '">';
						if (has_post_thumbnail()) {
							$html .= get_the_post_thumbnail(get_the_ID(), 'portfolio');
						} else {
							$html .= '<img src="' . get_template_directory_uri() . '/images/blank-image.png" alt="No Image" />';
						}
						$html .= '</a>' . "\n";
					$html .= '</div>' . "\n";
				$html .= '</article>' . "\n";
			if ($counter % 3 == 0 && $counter != esc_attr($atts['showposts'])) {
				$html .= '</div><div class="row clearfix">' . "\n";
			}
			$counter++;
			endwhile; wp_reset_postdata();
		$html .= '</div>' . "\n";
			$html .= '</div>' . "\n";
	else :
		//no posts found
	endif;
	return $html;
}
add_shortcode('mh_portfolio', 'mh_portfolio_shortcode');

?>