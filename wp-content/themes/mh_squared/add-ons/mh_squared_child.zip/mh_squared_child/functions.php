<?php

/***** Load Stylesheets *****/

function mh_squared_child_styles() {
    wp_enqueue_style('mh-squared-parent-style', get_template_directory_uri() . '/style.css');
    wp_enqueue_style('mh-squared-child-style', get_stylesheet_directory_uri() . '/style.css', array('mh-squared-parent-style'));
}
add_action('wp_enqueue_scripts', 'mh_squared_child_styles');

?>